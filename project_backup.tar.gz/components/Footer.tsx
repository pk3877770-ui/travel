import React from "react";
import Link from "next/link";
import { Plane, Mail, Phone, MapPin, Facebook, Twitter, Instagram, Linkedin, ChevronRight } from "lucide-react";

const Footer = () => {
  return (
    <footer className="bg-primary-dark text-white pt-24 pb-12 overflow-hidden relative noise-overlay">
      <div className="absolute inset-0 mesh-gradient opacity-10 pointer-events-none" />
      <div className="w-full max-w-[1440px] mx-auto px-6 md:px-12 relative z-10">
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-12 mb-20">
          {/* Brand & Info */}
          <div className="space-y-8">
            <div className="flex items-center gap-4">
              <div className="w-12 h-12 rounded-2xl bg-white/5 border border-white/10 flex items-center justify-center shadow-xl">
                <Plane className="w-7 h-7 text-accent -rotate-45" />
              </div>
              <span className="text-3xl font-black font-outfit tracking-tighter">KARMANA</span>
            </div>
            <p className="text-slate-400 leading-relaxed max-w-sm font-medium opacity-80">
              The world's premier travel concierge. From seamless sovereign flights to bespoke private estates, we craft journeys for the discerning few.
            </p>
            <div className="flex gap-4">
              {[Facebook, Twitter, Instagram, Linkedin].map((Icon, idx) => (
                <a
                  key={idx}
                  href="#"
                  className="w-10 h-10 rounded-full bg-white/5 border border-white/10 flex items-center justify-center text-white hover:bg-accent hover:text-primary transition-all hover:-translate-y-1"
                >
                  <Icon className="w-5 h-5" />
                </a>
              ))}
            </div>
          </div>

          {/* Travel Services */}
          <div>
            <h4 className="text-xl font-bold font-outfit mb-8">Travel Services</h4>
            <ul className="space-y-4">
              {[
                { name: "Sovereign Flights", href: "/flights" },
                { name: "Luxury Hotels", href: "/hotels" },
                { name: "Holiday Itineraries", href: "/holiday-packages" },
                { name: "Bespoke Services", href: "/services" },
                { name: "About the Brand", href: "/about" },
                { name: "Contact Concierge", href: "/contact" },
              ].map((item) => (
                <li key={item.name}>
                  <Link
                    href={item.href}
                    className="text-slate-400 hover:text-accent flex items-center gap-2 transition-colors group font-medium"
                  >
                    <ChevronRight className="w-4 h-4 text-accent transition-transform group-hover:translate-x-1" />
                    {item.name}
                  </Link>
                </li>
              ))}
            </ul>
          </div>

          {/* Guest Support */}
          <div>
            <h4 className="text-xl font-bold font-outfit mb-8">Guest Support</h4>
            <ul className="space-y-4">
              {[
                { name: "Member Help Center", href: "/help-center" },
                { name: "Flight Status & PNR", href: "/ticket-inquiry" },
                { name: "Refund & Cancellation", href: "/refund" },
                { name: "Terms & Conditions", href: "/terms" },
                { name: "Privacy & Data", href: "/privacy" },
              ].map((item) => (
                <li key={item.name}>
                  <Link
                    href={item.href}
                    className="text-slate-400 hover:text-accent flex items-center gap-2 transition-colors group font-medium"
                  >
                    <ChevronRight className="w-4 h-4 text-accent transition-transform group-hover:translate-x-1" />
                    {item.name}
                  </Link>
                </li>
              ))}
            </ul>
          </div>

          {/* Contact Info */}
          <div>
            <h4 className="text-xl font-bold font-outfit mb-8">Get in Touch</h4>
            <div className="bg-white/5 border border-white/10 rounded-3xl p-6 space-y-4 backdrop-blur-sm">
              <div className="flex items-start gap-4">
                <div className="w-10 h-10 rounded-full bg-accent/10 flex items-center justify-center shrink-0">
                  <Mail className="w-5 h-5 text-accent" />
                </div>
                <span className="text-slate-300">concierge@karmana.com</span>
              </div>
              <div className="flex items-start gap-4">
                <div className="w-10 h-10 rounded-full bg-accent/10 flex items-center justify-center shrink-0">
                  <Phone className="w-5 h-5 text-accent" />
                </div>
                <span className="text-slate-300">+91 (22) 6789 0123</span>
              </div>
              <div className="flex items-start gap-4">
                <div className="w-10 h-10 rounded-full bg-accent/10 flex items-center justify-center shrink-0">
                  <MapPin className="w-5 h-5 text-accent" />
                </div>
                <span className="text-slate-300">
                  World Trade Center, Cuffe Parade,<br />Mumbai, MH 400005
                </span>
              </div>
            </div>
          </div>
        </div>

        {/* Bottom Bar */}
        <div className="pt-8 border-t border-white/10 flex flex-col md:flex-row items-center justify-between gap-6 text-center md:text-left text-slate-500 text-sm">
          <p>© 2026 Karmana Travel Concierge. Crafted for the discerning traveler.</p>
          <div className="flex gap-6 grayscale opacity-50">
            {["Visa", "Mastercard", "Amex"].map((card) => (
              <span key={card} className="font-bold tracking-widest">{card.toUpperCase()}</span>
            ))}
          </div>
        </div>
      </div>
    </footer>
  );
};

export default Footer;
